"""
Logging utilities for TRUST-MCNet federated learning framework.

This module provides comprehensive logging capabilities for:
- Training metrics and performance tracking
- Trust score evolution monitoring
- Client participation and behavior logging
- System events and error tracking
"""

import logging
import json
import csv
import os
from datetime import datetime
from typing import Dict, List, Any, Optional
import pandas as pd
from pathlib import Path


class FederatedLogger:
    """
    Comprehensive logging system for federated learning experiments.
    
    Tracks metrics, trust scores, client behavior, and system events
    with multiple output formats and analysis capabilities.
    """
    
    def __init__(self, log_dir: str = "logs", experiment_name: str = "trust_mcnet"):
        """
        Initialize federated logger.
        
        Args:
            log_dir: Directory to store log files
            experiment_name: Name of the current experiment
        """
        self.log_dir = Path(log_dir)
        self.experiment_name = experiment_name
        self.timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        
        # Create log directory if it doesn't exist
        self.log_dir.mkdir(parents=True, exist_ok=True)
        
        # Initialize log files
        self.metrics_file = self.log_dir / f"{experiment_name}_metrics_{self.timestamp}.csv"
        self.trust_file = self.log_dir / f"{experiment_name}_trust_{self.timestamp}.csv"
        self.events_file = self.log_dir / f"{experiment_name}_events_{self.timestamp}.json"
        self.client_file = self.log_dir / f"{experiment_name}_clients_{self.timestamp}.csv"
        
        # Initialize data storage
        self.metrics_data = []
        self.trust_data = []
        self.events_data = []
        self.client_data = []
        
        # Setup Python logging
        self._setup_python_logging()
    
    def _setup_python_logging(self):
        """Setup Python logging configuration."""
        log_file = self.log_dir / f"{self.experiment_name}_{self.timestamp}.log"
        
        # Create logger
        self.logger = logging.getLogger(f"trust_mcnet_{self.experiment_name}")
        self.logger.setLevel(logging.DEBUG)
        
        # Clear existing handlers
        self.logger.handlers.clear()
        
        # File handler
        file_handler = logging.FileHandler(log_file)
        file_handler.setLevel(logging.DEBUG)
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        
        # Formatter
        formatter = logging.Formatter(
            '%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        file_handler.setFormatter(formatter)
        console_handler.setFormatter(formatter)
        
        # Add handlers
        self.logger.addHandler(file_handler)
        self.logger.addHandler(console_handler)
        
        self.logger.info(f"Initialized logging for experiment: {self.experiment_name}")
    
    def log_round_metrics(self, round_num: int, metrics: Dict[str, float]):
        """
        Log metrics for a federated learning round.
        
        Args:
            round_num: Round number
            metrics: Dictionary of metric name -> value
        """
        timestamp = datetime.now()
        
        # Prepare metrics entry
        metrics_entry = {
            'timestamp': timestamp,
            'round': round_num,
            **metrics
        }
        
        self.metrics_data.append(metrics_entry)
        
        # Log to console
        metrics_str = ", ".join([f"{k}: {v:.4f}" for k, v in metrics.items()])
        self.logger.info(f"Round {round_num} - {metrics_str}")
        
        # Save to CSV
        self._save_metrics_to_csv()
    
    def log_trust_scores(self, round_num: int, trust_scores: Dict[str, float]):
        """
        Log trust scores for all clients.
        
        Args:
            round_num: Round number
            trust_scores: Dictionary of client_id -> trust_score
        """
        timestamp = datetime.now()
        
        for client_id, trust_score in trust_scores.items():
            trust_entry = {
                'timestamp': timestamp,
                'round': round_num,
                'client_id': client_id,
                'trust_score': trust_score
            }
            self.trust_data.append(trust_entry)
        
        # Log summary
        avg_trust = sum(trust_scores.values()) / len(trust_scores) if trust_scores else 0.0
        self.logger.info(f"Round {round_num} - Average trust score: {avg_trust:.4f}")
        
        # Save to CSV
        self._save_trust_to_csv()
    
    def log_client_participation(self, round_num: int, client_id: str, 
                               participated: bool, metrics: Optional[Dict[str, float]] = None):
        """
        Log client participation and performance.
        
        Args:
            round_num: Round number
            client_id: Client identifier
            participated: Whether client participated in this round
            metrics: Optional client performance metrics
        """
        timestamp = datetime.now()
        
        client_entry = {
            'timestamp': timestamp,
            'round': round_num,
            'client_id': client_id,
            'participated': participated,
            **(metrics or {})
        }
        
        self.client_data.append(client_entry)
        
        # Log participation
        status = "participated" if participated else "did not participate"
        self.logger.debug(f"Round {round_num} - Client {client_id} {status}")
        
        # Save to CSV
        self._save_client_to_csv()
    
    def log_event(self, event_type: str, description: str, 
                 metadata: Optional[Dict[str, Any]] = None):
        """
        Log system events and important occurrences.
        
        Args:
            event_type: Type of event (e.g., 'attack_detected', 'client_selected')
            description: Human-readable description
            metadata: Additional event metadata
        """
        timestamp = datetime.now()
        
        event_entry = {
            'timestamp': timestamp.isoformat(),
            'event_type': event_type,
            'description': description,
            'metadata': metadata or {}
        }
        
        self.events_data.append(event_entry)
        
        # Log event
        self.logger.info(f"EVENT [{event_type}]: {description}")
        
        # Save to JSON
        self._save_events_to_json()
    
    def log_attack_detection(self, round_num: int, malicious_clients: List[str], 
                           detection_method: str):
        """
        Log malicious client detection.
        
        Args:
            round_num: Round number
            malicious_clients: List of detected malicious client IDs
            detection_method: Method used for detection
        """
        self.log_event(
            event_type="attack_detection",
            description=f"Detected {len(malicious_clients)} malicious clients in round {round_num}",
            metadata={
                'round': round_num,
                'malicious_clients': malicious_clients,
                'detection_method': detection_method
            }
        )
    
    def log_aggregation_info(self, round_num: int, participating_clients: List[str],
                           aggregation_method: str, aggregation_weights: Optional[Dict[str, float]] = None):
        """
        Log model aggregation information.
        
        Args:
            round_num: Round number
            participating_clients: List of clients that contributed to aggregation
            aggregation_method: Method used for aggregation
            aggregation_weights: Weights used in aggregation
        """
        self.log_event(
            event_type="model_aggregation",
            description=f"Aggregated {len(participating_clients)} client updates using {aggregation_method}",
            metadata={
                'round': round_num,
                'participating_clients': participating_clients,
                'aggregation_method': aggregation_method,
                'aggregation_weights': aggregation_weights
            }
        )
    
    def _save_metrics_to_csv(self):
        """Save metrics data to CSV file."""
        if self.metrics_data:
            df = pd.DataFrame(self.metrics_data)
            df.to_csv(self.metrics_file, index=False)
    
    def _save_trust_to_csv(self):
        """Save trust data to CSV file."""
        if self.trust_data:
            df = pd.DataFrame(self.trust_data)
            df.to_csv(self.trust_file, index=False)
    
    def _save_client_to_csv(self):
        """Save client data to CSV file."""
        if self.client_data:
            df = pd.DataFrame(self.client_data)
            df.to_csv(self.client_file, index=False)
    
    def _save_events_to_json(self):
        """Save events data to JSON file."""
        with open(self.events_file, 'w') as f:
            json.dump(self.events_data, f, indent=2, default=str)
    
    def get_metrics_summary(self) -> Dict[str, Any]:
        """
        Get summary statistics of logged metrics.
        
        Returns:
            Dictionary containing summary statistics
        """
        if not self.metrics_data:
            return {}
        
        df = pd.DataFrame(self.metrics_data)
        summary = {}
        
        # Numeric columns only
        numeric_cols = df.select_dtypes(include=['number']).columns
        
        for col in numeric_cols:
            if col != 'round':  # Exclude round number from statistics
                summary[col] = {
                    'mean': df[col].mean(),
                    'std': df[col].std(),
                    'min': df[col].min(),
                    'max': df[col].max(),
                    'final': df[col].iloc[-1] if len(df) > 0 else None
                }
        
        return summary
    
    def get_trust_evolution(self) -> Dict[str, List[float]]:
        """
        Get trust score evolution for each client.
        
        Returns:
            Dictionary mapping client_id to list of trust scores over time
        """
        if not self.trust_data:
            return {}
        
        df = pd.DataFrame(self.trust_data)
        trust_evolution = {}
        
        for client_id in df['client_id'].unique():
            client_data = df[df['client_id'] == client_id].sort_values('round')
            trust_evolution[client_id] = client_data['trust_score'].tolist()
        
        return trust_evolution
    
    def get_participation_stats(self) -> Dict[str, Any]:
        """
        Get client participation statistics.
        
        Returns:
            Dictionary containing participation statistics
        """
        if not self.client_data:
            return {}
        
        df = pd.DataFrame(self.client_data)
        
        # Calculate participation rates
        participation_stats = {}
        for client_id in df['client_id'].unique():
            client_data = df[df['client_id'] == client_id]
            total_rounds = len(client_data)
            participated_rounds = len(client_data[client_data['participated'] == True])
            
            participation_stats[client_id] = {
                'total_rounds': total_rounds,
                'participated_rounds': participated_rounds,
                'participation_rate': participated_rounds / total_rounds if total_rounds > 0 else 0.0
            }
        
        return participation_stats
    
    def export_analysis_report(self, output_file: Optional[str] = None) -> str:
        """
        Export comprehensive analysis report.
        
        Args:
            output_file: Output file path (optional)
            
        Returns:
            Report content as string
        """
        report_lines = []
        report_lines.append(f"TRUST-MCNet Experiment Report")
        report_lines.append(f"Experiment: {self.experiment_name}")
        report_lines.append(f"Timestamp: {self.timestamp}")
        report_lines.append("=" * 50)
        
        # Metrics summary
        metrics_summary = self.get_metrics_summary()
        if metrics_summary:
            report_lines.append("\nMETRICS SUMMARY:")
            for metric, stats in metrics_summary.items():
                report_lines.append(f"{metric}:")
                report_lines.append(f"  Mean: {stats['mean']:.4f}")
                report_lines.append(f"  Std:  {stats['std']:.4f}")
                report_lines.append(f"  Min:  {stats['min']:.4f}")
                report_lines.append(f"  Max:  {stats['max']:.4f}")
                report_lines.append(f"  Final: {stats['final']:.4f}")
        
        # Trust evolution
        trust_evolution = self.get_trust_evolution()
        if trust_evolution:
            report_lines.append("\nTRUST SCORE SUMMARY:")
            for client_id, scores in trust_evolution.items():
                if scores:
                    avg_trust = sum(scores) / len(scores)
                    final_trust = scores[-1]
                    report_lines.append(f"{client_id}: Avg={avg_trust:.3f}, Final={final_trust:.3f}")
        
        # Participation stats
        participation_stats = self.get_participation_stats()
        if participation_stats:
            report_lines.append("\nPARTICIPATION STATISTICS:")
            for client_id, stats in participation_stats.items():
                rate = stats['participation_rate']
                report_lines.append(f"{client_id}: {stats['participated_rounds']}/{stats['total_rounds']} rounds ({rate:.2%})")
        
        # Events summary
        if self.events_data:
            report_lines.append(f"\nTOTAL EVENTS LOGGED: {len(self.events_data)}")
            event_types = {}
            for event in self.events_data:
                event_type = event['event_type']
                event_types[event_type] = event_types.get(event_type, 0) + 1
            
            for event_type, count in event_types.items():
                report_lines.append(f"  {event_type}: {count}")
        
        report_content = "\n".join(report_lines)
        
        # Save to file if specified
        if output_file:
            with open(output_file, 'w') as f:
                f.write(report_content)
            self.logger.info(f"Analysis report saved to {output_file}")
        
        return report_content
    
    def cleanup(self):
        """Clean up and finalize logging."""
        # Save all pending data
        self._save_metrics_to_csv()
        self._save_trust_to_csv()
        self._save_client_to_csv()
        self._save_events_to_json()
        
        self.logger.info(f"Logging completed for experiment: {self.experiment_name}")
        
        # Close handlers
        for handler in self.logger.handlers[:]:
            handler.close()
            self.logger.removeHandler(handler)
