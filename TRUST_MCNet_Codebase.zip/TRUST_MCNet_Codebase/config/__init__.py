"""Configuration management utilities."""
