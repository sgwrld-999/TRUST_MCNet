"""Client module for federated learning."""

from .client import Client

__all__ = ["Client"]
