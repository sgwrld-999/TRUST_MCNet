# Model definitions for TRUST-MCNet
