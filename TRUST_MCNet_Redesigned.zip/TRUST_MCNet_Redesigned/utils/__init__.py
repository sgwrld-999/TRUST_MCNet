# Utility functions for TRUST-MCNet
