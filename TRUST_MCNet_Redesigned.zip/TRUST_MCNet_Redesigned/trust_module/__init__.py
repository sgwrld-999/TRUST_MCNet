# Trust evaluation mechanisms for TRUST-MCNet
